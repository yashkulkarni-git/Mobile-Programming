package com.example.tele;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        txt=findViewById(R.id.txt);

        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        String devicesoftwareversion = telephonyManager.getDeviceSoftwareVersion();
        String networkoperator = telephonyManager.getNetworkOperator();
        String carrier = telephonyManager.getNetworkOperatorName();

        String net=null;
        int nettype=telephonyManager.getNetworkType();

        switch (nettype){
            case TelephonyManager.NETWORK_TYPE_GSM:
                net="2g";
                break;
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                net = "3g";
            case TelephonyManager.NETWORK_TYPE_LTE:
                net="4g";
            case TelephonyManager.NETWORK_TYPE_NR:
                net="5g";
                break;
        }

        txt.setText(devicesoftwareversion+":"+networkoperator+":"+carrier+":"+nettype);



    }
}