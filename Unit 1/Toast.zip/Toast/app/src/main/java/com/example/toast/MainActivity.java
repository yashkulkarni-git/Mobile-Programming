package com.example.toast;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {

    EditText edt;
    Button btn;


    @Override
    public void onCreate(Bundle si){
        super.onCreate(si);
        setContentView(R.layout.activity_main);

        edt = findViewById(R.id.edit_box);
        btn = findViewById(R.id.subbtn);

        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(this,edt.getText().toString(),Toast.LENGTH_LONG).show();
    }
}
